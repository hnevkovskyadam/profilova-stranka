import React from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ProjectCard } from './components/ProjectCard';
import { AISection } from './components/AISection';
import { Footer } from './components/Footer';
import { ChatBot } from './components/ChatBot';
import { Code } from 'lucide-react';

function App() {
  const projects = [
    {
      title: "E-commerce Platforma",
      description: "Moderní e-shop postavený na React a TypeScript s důrazem na uživatelský zážitek a výkon.",
      imageUrl: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80",
      technologies: ["React", "TypeScript", "Tailwind CSS", "Node.js"],
      demoUrl: "https://stackblitz.com/edit/stackblitz-webcontainer-api-starter?embed=1"
    },
    {
      title: "AI Asistent",
      description: "Inteligentní chatbot využívající nejnovější technologie strojového učení pro podporu zákazníků.",
      imageUrl: "https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&q=80",
      technologies: ["Python", "TensorFlow", "FastAPI", "React"],
      demoUrl: "https://stackblitz.com/edit/react-ts-playground?embed=1"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <Hero />

      <section id="projekty" className="container mx-auto px-4 py-20">
        <div className="mb-12">
          <div className="flex items-center gap-3 mb-8">
            <Code className="text-indigo-600" size={32} />
            <h2 className="text-3xl font-bold text-gray-800">Projekty</h2>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            {projects.map((project, index) => (
              <ProjectCard key={index} {...project} />
            ))}
          </div>
        </div>

        <section id="ai" className="py-12">
          <AISection />
        </section>
      </section>

      <Footer />
      <ChatBot />
    </div>
  );
}

export default App;