import React from 'react';
import { Brain, Sparkles, Code, Cpu } from 'lucide-react';

export function AISection() {
  return (
    <div className="bg-gradient-to-br from-purple-50 to-indigo-50 p-8 md:p-12 rounded-xl shadow-lg">
      <div className="flex items-center gap-3 mb-8">
        <Brain className="text-purple-600" size={32} />
        <h2 className="text-3xl font-bold text-gray-800">Programování s umělou inteligencí</h2>
      </div>
      
      <div className="grid md:grid-cols-2 gap-8">
        <div className="space-y-6">
          <div className="flex items-start gap-4 group">
            <div className="p-2 bg-white rounded-lg shadow-md group-hover:shadow-lg transition-shadow">
              <Sparkles className="text-indigo-600" size={24} />
            </div>
            <div>
              <h3 className="font-semibold text-lg mb-2">Budoucnost je zde</h3>
              <p className="text-gray-600 leading-relaxed">
                Umělá inteligence revolucionizuje způsob, jakým vytváříme software. 
                Pomocí pokročilých AI nástrojů můžeme rychleji prototypovat, 
                debugovat a optimalizovat náš kód.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-4 group">
            <div className="p-2 bg-white rounded-lg shadow-md group-hover:shadow-lg transition-shadow">
              <Code className="text-purple-600" size={24} />
            </div>
            <div>
              <h3 className="font-semibold text-lg mb-2">Spolupráce člověka a AI</h3>
              <p className="text-gray-600 leading-relaxed">
                AI není náhradou za programátory, ale mocným nástrojem, který nám pomáhá
                být produktivnější a kreativnější. Společně můžeme vytvářet lepší
                a inovativnější řešení.
              </p>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="flex items-start gap-4 group">
            <div className="p-2 bg-white rounded-lg shadow-md group-hover:shadow-lg transition-shadow">
              <Cpu className="text-indigo-600" size={24} />
            </div>
            <div>
              <h3 className="font-semibold text-lg mb-2">Automatizace a Efektivita</h3>
              <p className="text-gray-600 leading-relaxed">
                S pomocí AI můžeme automatizovat rutinní úkoly a soustředit se na
                kreativní aspekty vývoje. To vede k vyšší produktivitě a lepší
                kvalitě kódu.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}