import React from 'react';
import { Menu, X, Github, Linkedin } from 'lucide-react';

export function Navbar() {
  const [isOpen, setIsOpen] = React.useState(false);

  return (
    <nav className="fixed w-full bg-white/80 backdrop-blur-md z-50 shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <a href="#" className="text-xl font-bold text-indigo-600">Portfolio</a>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <a href="#projekty" className="text-gray-600 hover:text-indigo-600 transition-colors">Projekty</a>
            <a href="#ai" className="text-gray-600 hover:text-indigo-600 transition-colors">AI</a>
            <div className="flex items-center space-x-4 ml-4">
              <a href="https://github.com" className="text-gray-600 hover:text-indigo-600 transition-colors">
                <Github size={20} />
              </a>
              <a href="https://linkedin.com" className="text-gray-600 hover:text-indigo-600 transition-colors">
                <Linkedin size={20} />
              </a>
            </div>
          </div>

          {/* Mobile Menu Button */}
          <button className="md:hidden" onClick={() => setIsOpen(!isOpen)}>
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden py-4">
            <div className="flex flex-col space-y-4">
              <a href="#projekty" className="text-gray-600 hover:text-indigo-600 transition-colors">Projekty</a>
              <a href="#ai" className="text-gray-600 hover:text-indigo-600 transition-colors">AI</a>
              <div className="flex space-x-4 pt-4">
                <a href="https://github.com" className="text-gray-600 hover:text-indigo-600 transition-colors">
                  <Github size={20} />
                </a>
                <a href="https://linkedin.com" className="text-gray-600 hover:text-indigo-600 transition-colors">
                  <Linkedin size={20} />
                </a>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}