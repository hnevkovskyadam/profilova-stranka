import React from 'react';
import { MessageSquare, X } from 'lucide-react';

interface ChatBotToggleProps {
  isOpen: boolean;
  onClick: () => void;
}

export function ChatBotToggle({ isOpen, onClick }: ChatBotToggleProps) {
  return (
    <button
      onClick={onClick}
      className={`
        fixed bottom-4 right-4 p-4 rounded-full shadow-lg
        transition-all duration-300 transform hover:scale-110
        ${isOpen ? 'bg-red-500 hover:bg-red-600' : 'bg-indigo-600 hover:bg-indigo-700'}
      `}
      aria-label={isOpen ? 'Zavřít chat' : 'Otevřít chat'}
    >
      {isOpen ? (
        <X className="text-white" size={24} />
      ) : (
        <MessageSquare className="text-white" size={24} />
      )}
    </button>
  );
}