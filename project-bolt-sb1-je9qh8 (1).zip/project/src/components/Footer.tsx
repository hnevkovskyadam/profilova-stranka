import React from 'react';
import { Heart } from 'lucide-react';

export function Footer() {
  const year = new Date().getFullYear();
  
  return (
    <footer className="bg-gray-900 text-gray-300 py-12">
      <div className="container mx-auto px-4">
        <div className="flex flex-col items-center justify-center space-y-4">
          <div className="flex items-center gap-2">
            <span>Vytvořeno s</span>
            <Heart className="text-red-500" size={20} />
            <span>v České republice</span>
          </div>
          <p className="text-sm text-gray-400">© {year} Mé Portfolio. Všechna práva vyhrazena.</p>
        </div>
      </div>
    </footer>
  );
}