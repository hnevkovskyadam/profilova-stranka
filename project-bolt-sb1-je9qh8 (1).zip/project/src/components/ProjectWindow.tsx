import React, { useState } from 'react';
import { Maximize2, Minimize2, ExternalLink } from 'lucide-react';

interface ProjectWindowProps {
  title: string;
  description: string;
  url: string;
}

export function ProjectWindow({ title, description, url }: ProjectWindowProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <div className="group bg-white rounded-xl shadow-lg overflow-hidden transform transition-all duration-300 hover:-translate-y-1 hover:shadow-xl">
      <div className="p-4 bg-gradient-to-r from-indigo-600 to-indigo-700 text-white flex justify-between items-center">
        <h3 className="font-semibold flex items-center gap-2">
          {title}
          <a 
            href={url} 
            target="_blank" 
            rel="noopener noreferrer"
            className="opacity-0 group-hover:opacity-100 transition-opacity"
          >
            <ExternalLink size={16} />
          </a>
        </h3>
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="p-2 hover:bg-white/10 rounded-full transition-colors"
          aria-label={isExpanded ? 'Zmenšit' : 'Zvětšit'}
        >
          {isExpanded ? <Minimize2 size={20} /> : <Maximize2 size={20} />}
        </button>
      </div>
      <div className="p-6">
        <p className="text-gray-600 mb-6 leading-relaxed">{description}</p>
        <div 
          className={`
            transition-all duration-500 ease-in-out 
            ${isExpanded ? 'h-[600px]' : 'h-[300px]'}
          `}
        >
          <iframe
            src={url}
            className="w-full h-full border-0 rounded-lg shadow-inner"
            title={title}
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          />
        </div>
      </div>
    </div>
  );
}