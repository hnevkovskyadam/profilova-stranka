import React from 'react';
import { Briefcase, ChevronDown, Github, Linkedin } from 'lucide-react';

export function Hero() {
  return (
    <header className="relative min-h-screen flex items-center justify-center">
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1517134191118-9d595e4c8c2b?auto=format&fit=crop&q=80")'
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-indigo-600/90 to-purple-600/90"></div>
      </div>
      
      <div className="relative container mx-auto px-4 text-center text-white">
        <div className="animate-fadeIn">
          <div className="flex justify-center items-center gap-4 mb-6">
            <Briefcase className="w-12 h-12" />
            <h1 className="text-5xl font-bold">Mé Portfolio</h1>
          </div>
          
          <p className="text-xl text-indigo-100 max-w-2xl mx-auto mb-8">
            Vítejte v mém portfoliu projektů. Zde najdete ukázky mé práce
            a experimentů s nejnovějšími technologiemi.
          </p>

          <div className="flex justify-center gap-4 mb-12">
            <a 
              href="https://github.com"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-white/10 p-3 rounded-full hover:bg-white/20 transition-colors"
            >
              <Github size={24} />
            </a>
            <a 
              href="https://linkedin.com"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-white/10 p-3 rounded-full hover:bg-white/20 transition-colors"
            >
              <Linkedin size={24} />
            </a>
          </div>

          <a 
            href="#projekty"
            className="inline-flex items-center gap-2 px-6 py-3 bg-white text-indigo-600 rounded-full font-semibold hover:bg-indigo-50 transition-colors"
          >
            Prozkoumat projekty
            <ChevronDown className="animate-bounce" />
          </a>
        </div>
      </div>
    </header>
  );
}